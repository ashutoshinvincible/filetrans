package com.gojek.parkinglot.command;

import java.util.List;

import com.gojek.parkinglot.ParkingModel;
import com.gojek.parkinglot.ParkingSlot;

public class LeaveCommand implements Command {
	@Override
	public boolean validate(String[] args) {
		if (args.length != 2) {
			System.out.println("");
			throw new IllegalArgumentException("Wrong number of input for Create command");
		}
		return true;
	}

	@Override
	public void execute(ParkingModel pb, String[] args) {
		pb.getParkingSlotAssign().add(args[1]);
		pb.getRegParkingSlot()
				.put(pb.getParkingSlot().get(Integer.valueOf(args[1]) - 1).getVehicleRegNumber(), null);
		List<ParkingSlot> plist = pb.getColorParkingSlot()
				.get(pb.getParkingSlot().get(Integer.valueOf(args[1]) - 1).getVehicleColor());
		int i = -1;
		for (ParkingSlot ps : plist) {
			if (ps.getParkingSlot() == args[1]) {
				i++;
				break;
			}
			i++;
		}
		plist.remove(i);
		pb.getParkingSlot().set(Integer.valueOf(args[1]) - 1, null);
		System.out.println("Slot number " + args[1] + " is free");
	}

}
