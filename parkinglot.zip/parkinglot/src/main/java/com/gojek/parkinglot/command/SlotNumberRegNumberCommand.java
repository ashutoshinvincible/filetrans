package com.gojek.parkinglot.command;

import com.gojek.parkinglot.ParkingModel;

public class SlotNumberRegNumberCommand implements Command {

	@Override
	public boolean validate(String[] args) {
		if(args.length!=2) {
			System.out.println("");
			throw new IllegalArgumentException("Wrong number of input for above command");
		}
		return true;
	}

	@Override
	public void execute(ParkingModel pb, String[] args) {
		// TODO Auto-generated method stub	
		if(pb.getRegParkingSlot().get(args[1])!= null) {
		System.out.println(pb.getRegParkingSlot().get(args[1]).getParkingSlot());
		}else {
			System.out.println("Not found");
		}
	}
	
}
