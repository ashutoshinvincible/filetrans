package com.gojek.parkinglot.command;

import com.gojek.parkinglot.ParkingModel;
import com.gojek.parkinglot.ParkingSlot;

public class StatusCommand implements Command {
    @Override
	public boolean validate(String[] args) {		
		return true;
	}
	@Override
	public void execute(ParkingModel pb, String[] args) {		
		System.out.println("Slot No.   Registration No.  Colour");
		for(ParkingSlot ps:pb.getParkingSlot()) {
			if(ps!=null)
			System.out.println(ps.getParkingSlot()+"     "+"     "+ps.getVehicleRegNumber()+"     "+ps.getVehicleColor());
		}
	}
}
