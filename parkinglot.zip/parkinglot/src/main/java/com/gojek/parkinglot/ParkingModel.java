package com.gojek.parkinglot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class ParkingModel {
	private int lastFillIndex = 0;
	private int maxSlots = 0;

	private ArrayList<ParkingSlot> parkingSlot = new ArrayList<ParkingSlot>();
	private Map<String, List<ParkingSlot>> colorParkingSlot = new HashMap<String, List<ParkingSlot>>();
	private Map<String, ParkingSlot> regParkingSlot = new HashMap<String, ParkingSlot>();
	private TreeSet<String> parkingSlotAssign = new TreeSet<String>();

	public TreeSet<String> getParkingSlotAssign() {
		return parkingSlotAssign;
	}

	public void setParkingSlotAssign(TreeSet<String> parkingSlotAssign) {
		this.parkingSlotAssign = parkingSlotAssign;
	}

	public ArrayList<ParkingSlot> getParkingSlot() {
		return parkingSlot;
	}

	public void setParkingSlot(ArrayList<ParkingSlot> parkingSlot) {
		this.parkingSlot = parkingSlot;
	}

	public Map<String, List<ParkingSlot>> getColorParkingSlot() {
		return colorParkingSlot;
	}

	public void setColorParkingSlot(Map<String, List<ParkingSlot>> colorParkingSlot) {
		this.colorParkingSlot = colorParkingSlot;
	}

	public Map<String, ParkingSlot> getRegParkingSlot() {
		return regParkingSlot;
	}

	public void setRegParkingSlot(Map<String, ParkingSlot> regParkingSlot) {
		this.regParkingSlot = regParkingSlot;
	}

	public int getLastFillIndex() {
		return lastFillIndex;
	}

	public void setLastFillIndex(int lastFillIndex) {
		this.lastFillIndex = lastFillIndex;
	}

	public int incrementAndGetLastFillIndex() {
		return ++lastFillIndex;
	}

	public int decrementAndGetLastFillIndex() {
		return --lastFillIndex;
	}

	public int getMaxSlots() {
		return maxSlots;
	}

	public void setMaxSlots(int maxSlots) {
		this.maxSlots = maxSlots;
	}
}
