package com.gojek.parkinglot.command;

import com.gojek.parkinglot.ParkingModel;
import com.gojek.parkinglot.ParkingSlot;

public class SlotNumberColourCommand implements Command {

	@Override
	public boolean validate(String[] args) {
		if (args.length != 2) {
			System.out.println("");
			throw new IllegalArgumentException("Wrong number of input for above command");
		}
		return true;
	}

	@Override
	public void execute(ParkingModel pb, String[] args) {
		// TODO Auto-generated method stub
		String reg = "";
		if (pb.getColorParkingSlot().get(args[1]) == null) {
			return;
		}
		for (ParkingSlot ps : pb.getColorParkingSlot().get(args[1])) {
			reg = reg + ps.getParkingSlot() + ", ";
		}
		System.out.println(reg.substring(0, reg.length() - 2));
	}

}
