#!/bin/bash
mvn clean install
if [ ! -z "$1"]
then 
echo $1
java -jar target/parkinglot-0.0.1-SNAPSHOT.jar "../$1"
else 
echo "input file doesnot exist"
java -jar target/parkinglot-0.0.1-SNAPSHOT.jar
fi
